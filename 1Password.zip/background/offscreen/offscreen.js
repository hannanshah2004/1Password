
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6f49d095-a065-50ec-82d7-99b39e917649")}catch(e){}}();
import"/chunks/chunk-ZO4PLK6J.js";import"/chunks/chunk-ZFTIJJWF.js";import{a as r}from"/chunks/chunk-6YNELV3X.js";import"/chunks/chunk-2DMC74UK.js";import"/chunks/chunk-KXLNOMU5.js";import"/chunks/chunk-SA4ONVCB.js";import{g as s}from"/chunks/chunk-RRQNY46F.js";import"/chunks/chunk-LNKEWYKX.js";import"/chunks/chunk-3FHYWD3H.js";import"/chunks/chunk-SBTOIRTT.js";browser.runtime.onMessage.addListener(async o=>{let e=o.name;if(e==="GetStorageEntries")return Promise.resolve({type:"Success",data:[...r()]});s(e)});

//# debugId=6f49d095-a065-50ec-82d7-99b39e917649
