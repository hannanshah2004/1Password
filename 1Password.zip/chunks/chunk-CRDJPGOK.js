
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f755f7ec-cefd-52ce-8749-f36400130bce")}catch(e){}}();
import{a,b as n}from"/chunks/chunk-OBKOLL2W.js";import{d as r}from"/chunks/chunk-SBTOIRTT.js";var e=r(a()),s=r(n()),c=(0,e.createContext)({}),z=({children:t})=>{let[w,p]=(0,e.useState)(d(window.innerWidth));return(0,e.useLayoutEffect)(()=>{let i=()=>{let o=d(window.innerWidth),u=document.body.getAttribute("data-viewport-size");o!==u&&document.body.setAttribute("data-viewport-size",o),p(o)};return i(),window.addEventListener("resize",i),()=>{window.removeEventListener("resize",i)}},[]),(0,s.jsx)(c.Provider,{value:w,children:t})},d=t=>t<500?"small":"medium";export{c as a,z as b};

//# debugId=f755f7ec-cefd-52ce-8749-f36400130bce
