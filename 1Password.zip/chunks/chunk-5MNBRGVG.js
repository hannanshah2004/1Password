
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7d3610c9-e56b-591d-99e2-28f234df9e45")}catch(e){}}();
var u={accountUuid:"mock-static-app-list-user-uuid",userUuid:"mock-static-app-list-user-uuid"};export{u as a};

//# debugId=7d3610c9-e56b-591d-99e2-28f234df9e45
