
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="81d94900-e2a3-5be7-87f8-91396ea02c7d")}catch(e){}}();
import{a as r}from"/chunks/chunk-ZFTIJJWF.js";self.browser||(self.browser=r());

//# debugId=81d94900-e2a3-5be7-87f8-91396ea02c7d
