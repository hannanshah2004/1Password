
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="368e1a32-9f25-5c8c-a845-8909dd37deb5")}catch(e){}}();
function a(e){return!!(e&&typeof e=="object"&&["Success","Error"].includes(e.type))}export{a};

//# debugId=368e1a32-9f25-5c8c-a845-8909dd37deb5
