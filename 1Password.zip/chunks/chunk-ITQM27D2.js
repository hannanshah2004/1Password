
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bfd898e1-9572-5506-8785-c3b97c6c9ccc")}catch(e){}}();
import{g as n,j as g,k as e,l as r}from"/chunks/chunk-QXBY3YME.js";import{c as s}from"/chunks/chunk-KXLNOMU5.js";var c=class{constructor(o){this.makeLogger=(o,a)=>n()?(...i)=>{o.apply(console,i);try{let t=window.indexedDB.open(e);t.onsuccess=()=>{let p=t.result.transaction("logs","readwrite").objectStore(r),D={date:s(),timestamp:Date.now(),message:g(i),type:a,origin:this._origin};p.add(D)}}catch{}}:o;this._origin=o}};export{c as a};

//# debugId=bfd898e1-9572-5506-8785-c3b97c6c9ccc
