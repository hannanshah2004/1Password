
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6b59bd99-7edc-5464-ba68-d3d0143b7f23")}catch(e){}}();
var s=["features","config","all-vaults","opxAutomaticallyDisabled","accounts","devtools","notification-history","watchtower_settings","sls_app_connected","devtools-add-account-prompt","privacy-force-sandbox","privacy-key-sandbox-api-key","diagnostics","whatsnew-features"];var n=()=>{let t=new Map;return s.forEach(o=>{let e=window.localStorage.getItem(o);e&&t.set(o,e)}),t},c=()=>window.matchMedia("(prefers-color-scheme: dark)").matches;export{n as a,c as b};

//# debugId=6b59bd99-7edc-5464-ba68-d3d0143b7f23
