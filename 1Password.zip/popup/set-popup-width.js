
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ce5e9eee-2ef1-5903-b7d7-d77772ad2696")}catch(e){}}();
import{c as t}from"/chunks/chunk-CWR7GH3R.js";import"/chunks/chunk-XVROIDRE.js";import"/chunks/chunk-3FHYWD3H.js";import"/chunks/chunk-SBTOIRTT.js";var d=t()??"double-pane";document.body.setAttribute("data-width",d);

//# debugId=ce5e9eee-2ef1-5903-b7d7-d77772ad2696
